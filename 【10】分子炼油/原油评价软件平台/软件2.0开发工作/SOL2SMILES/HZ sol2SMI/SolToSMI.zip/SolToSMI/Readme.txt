SOL 转换至SMILES converter
程序目前是cygwin下编译的命令行exe
将压缩包展开到目录： 如 SOLToSMI
在console下运行SOLToMolGen.cmd 即可， 可以由外部程序调用shell的方式进行。
缺省输入文件是目录下的SOLTest.dat, 这个文件是csv形式逗号分离的文件，第一行是表头，列出所有SOL向量名称，第二行起是可以由用户输入的SOL向量的数值，每一行对应一个组分。
输入文件名字可以更改，对应修改上述cmd文件里的相应行即可。文件格式必须一致。
SMILES code输出在SolSPC目录下SMICode.lst文件，每一行对应一个组分的SMILEs code， 顺序与输入文件一致。
如果所输入的SOL向量生成的core结构在软件内建库内不匹配，会report到SOLspc下SOLMissedSPC.lst文件。

