MatlabBGL
=========

A C library wrapping the Boost graph library and a Matlab wrapper for the 
Boost graph library.

Features
--------

* Wrappers around most of the Boost graph library
functions
* Copy-free implementations of many graph algorithms
on Matlab's native sparse matrix type.
* Works effeciently on huge problems

Synopsis
--------

[coming soon]

License
-------

Matlab code: BSD
libmbgl code: GPLv2

Copyright David F. Gleich, 2006-2011

