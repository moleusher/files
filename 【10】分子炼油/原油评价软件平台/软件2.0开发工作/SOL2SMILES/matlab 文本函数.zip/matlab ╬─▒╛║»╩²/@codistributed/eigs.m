function varargout = eigs(varargin) %#ok<STOUT> method errors unconditionally
%EIGS Find a few eigenvalues and eigenvectors of a codistributed matrix
%   
%   Not yet implemented.
%   
%   See also EIGS, CODISTRIBUTED.


%   Copyright 2007-2012 The MathWorks, Inc.

error(message('parallel:distributed:EigsNotImplemented'));
