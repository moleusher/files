function C = mat2cell(A,varargin) %#ok<STOUT,INUSD>
%MAT2CELL Break codistributed matrix up into a codistributed cell array of underlying data.
%   Not yet implemented.
%   


%   Copyright 2009-2011 The MathWorks, Inc.

error(message('parallel:distributed:Mat2cellNotImplemented'));
